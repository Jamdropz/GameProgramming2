﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class gMaster : MonoBehaviour {

	public Transform grassObj;
	public static string currentTool = "none";

	public static int flowerSeeds = 5;
	public static int carrotSeeds = 6;
	public static int onionSeeds  = 7;



	// Use this for initialization
	void Start () {
		for (int xPos = -7; xPos < 15; xPos += 2) 
		{
		
			for (int yPos = 3; yPos > -10; yPos -= 2)
			{
			
				Instantiate (grassObj, new Vector2 (xPos, yPos), grassObj.rotation);
			}

		}
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
