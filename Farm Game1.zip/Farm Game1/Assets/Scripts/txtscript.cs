﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class txtscript : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
		GetComponent<Renderer>().sortingOrder = 6;
	}
	
	// Update is called once per frame
	void Update () {
	
		if (gameObject.name == "flowertxt")
		{ 
			GetComponent<TextMesh> ().text = "Flower Seeds :  " + gMaster.carrotSeeds;
		}
		if (gameObject.name == "carrottxt")
		{ 
			GetComponent<TextMesh> ().text = "Carrot Seeds :  " + gMaster.carrotSeeds;
		}
		if (gameObject.name == "oniontxt")
		{ 
			GetComponent<TextMesh> ().text = "Onion Seeds :  " + gMaster.onionSeeds;
		}
	}


	void OnMouseDown()
	{
		if (gameObject.name == "flowertxt") { 
		
			gMaster.currentTool = "flower";
		}
		if (gameObject.name == "carrottxt")
		{ 
			gMaster.currentTool = "carrot";
		}
		if (gameObject.name == "oniontxt")
		{ 
			gMaster.currentTool = "onion";

		}
	}
}
