﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


//for weeds

public class plantcontrol : MonoBehaviour {

	public Sprite noplantobj;
	public Sprite flower1;
	public Sprite flower2;

	public Sprite carrot1;
	public Sprite carrot2;

	public Sprite onion1;
	public Sprite onion2;


	public float growTime=0; 

	public Transform plotObj;

	public string watered = "n";



	public string currentSeed = "" ;



	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {

		if (currentSeed != "")
		{
			growTime +=  Time.deltaTime;
		}

		if ((growTime > 8)  && (watered == "n"))
		{
			currentSeed = "";
			growTime = 0;
			GetComponent<SpriteRenderer>().sprite = noplantobj;
		}

		if ((growTime > 12) && (watered == "y"))
		{
			if (currentSeed == "flower")
			{
				GetComponent<SpriteRenderer>().sprite = flower2;
			}

				if (currentSeed == "carrot"){
					GetComponent<SpriteRenderer>().sprite = carrot2;
				}
				
					if (currentSeed == "onion"){
						GetComponent<SpriteRenderer>().sprite = onion2;
					}
		}
	}

	void OnMouseDown ()
	{Debug.Log ("clicked on weed");
		
		if (gMaster.currentTool == "scythe") 
		{
			//Destroy (gameObject);
			GetComponent<SpriteRenderer>().sprite= noplantobj;
		}

		if ((gMaster.currentTool == "flower") && (GetComponent<SpriteRenderer>().sprite == noplantobj))
		{
			
			GetComponent<SpriteRenderer>().sprite= flower1;
			currentSeed = "flower" ;
		}

		if ((gMaster.currentTool == "onion") && (GetComponent<SpriteRenderer>().sprite == noplantobj))
		{

			GetComponent<SpriteRenderer>().sprite= onion1;
			currentSeed = "onion";
		}
		if ((gMaster.currentTool == "carrot") && (GetComponent<SpriteRenderer>().sprite == noplantobj))
		{

			GetComponent<SpriteRenderer>().sprite= carrot1;
			currentSeed = "carrot";
		}

		if ((gMaster.currentTool == "bucket") &&  (GetComponent<SpriteRenderer>().sprite == noplantobj))
		{
		{

			plotObj.GetComponent<SpriteRenderer>().color= new Color(0,0,1);
				watered = "y";
		}


	}
}
}