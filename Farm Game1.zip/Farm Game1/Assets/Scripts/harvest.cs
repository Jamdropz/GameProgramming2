﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class harvest : MonoBehaviour {

	public Transform cursorObj;
	public Transform seedInvObj;


	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
	void OnMouseDown()
	{
		if (gameObject.name == "scythe") {
			
			gMaster.currentTool = "scythe";
		
		}

		if (gameObject.name == "seeds") {
		
			gMaster.currentTool = "seeds";
			seedInvObj.transform.position = new Vector2 (9, -4);
		
		}
		if (gameObject.name == "bucket") {

			gMaster.currentTool = "bucket";

		}


		cursorObj.transform.position = transform.position;
		Debug.Log (gMaster.currentTool);
		 

	}
}
